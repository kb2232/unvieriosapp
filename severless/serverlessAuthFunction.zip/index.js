const AWS = require('aws-sdk');
const bcrypt = require('bcrypt');
const docClient = new AWS.DynamoDB.DocumentClient({region: "us-east-1"});
exports.handler = async (event) => {
  console.log("......process starts......")
  // TODO implement
  let response = {
    statusCode: 200,
    body: JSON.stringify('Hello from Lambda!'),
  };
  const { email, password} = event;
  let newPassword;
  
  let params = {
    TableName:'usersAuthentication',
    Key:{
      email: email
    }
  }
  /* check if your email or username is already registered */
  try {
    console.log("......fetching user starts......")
    const data = await docClient.get(params);
    if(data){
      // item already exist
      response.body = JSON.stringify(data, null, 2);
      console.log("......user exists......")
      return response;
    } else{
      // there is not item 

      /* generate the salt and hash it */
      bcrypt.genSalt(10, (err, salt) => {
        if (err) return next(err);
        bcrypt.hash(password, salt, (err, hash) => {
          if (err) return next(err);
          newPassword = hash;
        });
      });
      
      // save new item
      try {

        // create new user
        params = {
          TableName:'usersAuthentication',
          Key:{
            email: email,
            password: newPassword
          }
        }
        const data = await docClient.put(params);
        if(data){
          console.log("......new user created......")
          response.body = JSON.stringify(data, null, 2);
          return response;
        }
        response.body = JSON.stringify('New User could not be created');
        return response;

      } catch (error) {

        response.statusCode = 400;
        response.body = JSON.stringify(error, null, 2);
        return response;

      }
    }
  } catch (error) {
      response.statusCode = 400;
      response.body = JSON.stringify(error, null, 2);
      return response;
  }

};